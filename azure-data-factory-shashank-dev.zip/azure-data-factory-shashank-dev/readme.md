# Azure Data Factory Configuration Files

Blocked change



